import { useEffect, useMemo, useState } from "react";
import { useSkills } from "../../hooks/useSkills.js";
import { skills as api } from "../../api/endpoints.js";
import { useApp } from "../../shell/AppContext.js";
import Button from "../../components/Button.jsx";
import IconButton from "../../components/IconButton.jsx";
import SearchBar from "../../components/SearchBar.jsx";
import Badge from "../../components/Badge.jsx";
import Notice from "../../components/Notice.jsx";
import Switch from "../../components/Switch.jsx";
import ActionRow from "../../components/ActionRow.jsx";
import Collapse from "../../components/Collapse.jsx";

import Icon from "../../components/Icon.jsx";
import SkillStudio from "./SkillStudio.jsx";

// The Skill Genie. Agents send their request; the Genie returns only the skills that fit.
export default function SkillSelector({ active, onDeleted }) {
  const { loadCounts } = useApp();
  const sk = useSkills();
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("new");
  const [shown,setShown]=useState(10);
  const [adding, setAdding] = useState(false);
  const [text, setText] = useState("");
  const [tryText, setTryText] = useState("");
  const [trying, setTrying] = useState(null);
  const [open, setOpen] = useState({});
  const [studio, setStudio] = useState(null);
  const [template, setTemplate] = useState("");
  const [limit, setLimit] = useState(5000);
  useEffect(() => { if (active) api.list().then((d) => { setTemplate(d.template); setLimit(d.max_tokens); }).catch(() => {}); }, [active]);

  useEffect(() => { if (active) sk.load(); }, [active]); // eslint-disable-line react-hooks/exhaustive-deps

  const list = useMemo(() => sk.items.filter((s) => {
    if (filter === "on" && !s.enabled) return false;
    if (filter === "off" && s.enabled) return false;
    const hay = (s.name + " " + s.description).toLowerCase();
    return !q || hay.includes(q.toLowerCase());
  }).sort((a,b)=>filter==='used'?b.uses-a.uses:filter==='updated'?b.updated.localeCompare(a.updated):filter==='new'?b.created.localeCompare(a.created):a.name.localeCompare(b.name)), [sk.items,filter,q]);
  const enabledCount = sk.items.filter((s) => s.enabled).length;
  const pendingCount = sk.items.filter((s) => s.pending).length;

  const readFile = (f) => f.text().then((t) => sk.add(t, "file"));
  const addText = async () => { if (await sk.add(text, "paste")) { setText(""); setAdding(false); } };

  const runTry = async () => {
    setTrying({ busy: true });
    try { setTrying(await api.try(tryText)); }
    catch (e) { setTrying({ error: e.message }); }
    loadCounts();
  };

  return (
    <div className="stack">
      <SearchBar id="sk-q" type="search" placeholder="Search skills" value={q} onChange={(e) => setQ(e.target.value)}>
        <IconButton id="sk-gen" icon="wand" label="Write a skill with AI" size="lg" onClick={() => setStudio({ fresh: true })} />
        <IconButton id="sk-add-open" icon={adding ? "x" : "plus"} label={adding ? "Close" : "Add a skill"} variant="solid" size="lg" onClick={() => setAdding((a) => !a)} />
      </SearchBar>

      <div className="card">
        <Collapse open={adding}>
          {adding ? (
            <div className="editor" style={{ marginTop: 12 }}>
              <textarea id="sk-text" className="fld" style={{ minHeight: 160, fontFamily: "var(--mono)", fontSize: 13 }}
                placeholder={"---\nname: my-skill\ndescription: Use when ...\n---\nInstructions..."} value={text} onChange={(e) => setText(e.target.value)} />
              <p className="muted small" style={{ margin: 0 }}>Max {limit} tokens. Start the description with "Use when ...".</p>
              <div className="row">
                <Button id="sk-save" onClick={addText}>Save skill</Button>
                <Button variant="ghost" id="sk-template" onClick={() => setText(template)}>Use template</Button>
                <label className="fld" style={{ width: "auto", cursor: "pointer", padding: "9px 14px" }}>
                  Choose .md file
                  <input type="file" accept=".md,text/markdown,text/plain" hidden onChange={(e) => e.target.files[0] && readFile(e.target.files[0])} />
                </label>
              </div>
            </div>
          ) : null}
        </Collapse>
        <div className="filter">
          <select aria-label="Sort and filter skills" className="fld" style={{width:'auto',maxWidth:'65%',fontSize:13}} value={filter} onChange={e=>{setFilter(e.target.value);setShown(10);}}>
            <option value="new">Newly added</option><option value="updated">Recently updated</option><option value="used">Most used</option><option value="all">All A–Z</option><option value="on">Enabled</option><option value="off">Disabled</option>
          </select>
          <div className="cluster">
            {pendingCount ? <Badge tone="rule">{pendingCount} to review</Badge> : null}
            <label className="count-pill" htmlFor="sk-max" title="Total maximum number of skills selected per request">
              Skills per request <select id="sk-max" aria-label="Maximum skills per request" value={sk.max} onChange={(e) => sk.saveMax(Number(e.target.value))}>
                {Array.from({length:8},(_,i)=><option key={i+1} value={i+1}>{i+1}</option>)}
              </select>
            </label>
          </div>
        </div>
        <Notice tone={sk.message.tone} id="sk-msg">{sk.message.text}</Notice>
      </div>

<div id="sk-list" className="stack list">
        {!sk.loaded ? [0, 1, 2].map((k) => <div className="skel" key={k} />) : null}
        {list.slice(0,q?list.length:shown).map((s) => {
          const key = s.name, isOpen = !!open[key];
          return (
            <div className={"dcard" + (isOpen ? " open" : "")} key={s.name}>
              <div className="dhead">
                <button type="button" className="dmain" aria-expanded={isOpen} onClick={() => setOpen((o) => ({ ...o, [key]: !o[key] }))}>
                  <span className={"ic " + (s.enabled ? "ok" : "lock")}><Icon name={s.enabled ? "skills" : "lock"} size={18} /></span>
                  <span className="tt"><code>{s.name}</code><small>{s.pending ? <b className="ok-amber">Needs review </b> : null}{s.core ? "Prioritized " : ""}{s.tokens} tokens, from {s.source}</small></span>
                  <span className="chev"><Icon name="chev" size={18} /></span>
                </button>
                <Switch checked={s.enabled} onChange={(v) => sk.toggle(s.name, "enabled", v)} title={s.pending ? "Approve and enable" : "Enable or disable"} />
              </div>
              <Collapse open={isOpen}>
                <div className="pad">
                  <p className="small" style={{ margin: 0, color: "var(--ink2)" }}>{s.description}</p>
                  {s.warnings && s.warnings.length ? <Notice tone="bad">Check before use: {s.warnings.join("; ")}.</Notice> : null}
                  <ActionRow className="row" actions={[
                    { key: "edit", label: "Edit skill", icon: "pencil", onClick: () => setStudio({ name: s.name }) },
                    { key: "core", label: s.core ? "Stop prioritizing" : "Prioritize this skill", icon: "bolt", on: s.core,
                      onClick: () => sk.toggle(s.name, "core", !s.core) },
                    { key: "del", label: "Delete skill", icon: "trash", variant: "danger", onClick: async () => { if (await sk.remove(s.name)) onDeleted?.(); },
                      confirm: { text: "Delete " + s.name + " and all of its linked scripts and resources?", yes: "Yes, delete" } },
                  ]} />
                </div>
              </Collapse>
            </div>
          );
        })}
        {!q && list.length>shown?<button type="button" className="fld" onClick={()=>setShown(n=>n+10)}>Show 10 more skills ({list.length-shown} remaining)</button>:null}
        {!list.length && sk.loaded ? <p className="empty">{sk.items.length ? "No skill matches." : "No skills yet. Add one above."}</p> : null}
      </div>

      <div className="card">
        <div className="chead">
          <span className="chip brass"><Icon name="skills" size={19} /></span>
          <div className="grow"><h3>Try it</h3><div className="sub">See which skills an agent would receive for a request</div></div>
        </div>
        <div style={{ marginTop: 12 }}>
          <SearchBar id="sk-try" icon="skills" placeholder="for example: make a remotion video" value={tryText} onChange={(e) => setTryText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && tryText.trim()) runTry(); }}>
            <IconButton id="sk-try-go" icon="up" label="Ask" variant="solid" size="lg" onClick={runTry} disabled={!tryText.trim() || trying?.busy} />
          </SearchBar>
        </div>
        {trying && !trying.busy ? (
          <div className="stack" style={{ marginTop: 12 }}>
            {trying.error ? <Notice tone="bad">{trying.error}</Notice> : null}
            {trying.picks && !trying.picks.length ? <Notice>No skill is needed for that request.</Notice> : null}
            {(trying.picks || []).map((p) => (
              <div className="suggest" key={p.name}><b>{p.name}</b><small>{p.why}</small></div>
            ))}
            {trying.picks ? <p className="muted small" style={{ margin: 0 }}>
              {trying.mode === "ai" ? "Chosen by an AI model." : "Chosen by keywords."}{trying.note ? " " + trying.note : ""}
            </p> : null}
          </div>
        ) : null}
      </div>
      <SkillStudio target={studio} onClose={() => setStudio(null)}
        onSaved={(m, warn) => { sk.say(m, warn ? "bad" : "ok"); sk.load(); loadCounts(); }} />
    </div>
  );
}
